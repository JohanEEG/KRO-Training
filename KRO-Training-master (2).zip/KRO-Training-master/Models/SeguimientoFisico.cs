using System.ComponentModel.DataAnnotations;

namespace KRO_Training_Performance.Models
{
    public class SeguimientoFisico
    {
        public int Id { get; set; }

        [Required]
        public int ClienteId { get; set; }

        [Required]
        public double Peso { get; set; }

        public double Estatura { get; set; }

        public double Cintura { get; set; }

        public double Pecho { get; set; }

        public double Brazo { get; set; }

        public double Pierna { get; set; }

        public string Observaciones { get; set; } = string.Empty;

        public DateTime Fecha { get; set; } = DateTime.Now;
    }
}