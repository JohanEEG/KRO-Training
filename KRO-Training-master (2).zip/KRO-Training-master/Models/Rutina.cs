using System.ComponentModel.DataAnnotations;

namespace KRO_Training_Performance.Models
{
    public class Rutina
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la rutina es obligatorio.")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "La descripción es obligatoria.")]
        public string Descripcion { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe indicar los ejercicios de la rutina.")]
        public string Ejercicios { get; set; } = string.Empty;

        public string Nivel { get; set; } = string.Empty;

        public int DuracionMinutos { get; set; }
    }
}