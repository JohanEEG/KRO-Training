﻿using Microsoft.AspNetCore.Mvc;
using KRO_Training_Performance.Models;
using System.Linq;

namespace KRO_Training_Performance.Controllers
{
    public class SeguimientoFisicoController : Controller
    {
        private static List<SeguimientoFisico> seguimientos =
            new List<SeguimientoFisico>();



        [HttpGet]
        public IActionResult RegistrarEvaluacion()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RegistrarEvaluacion(SeguimientoFisico seguimiento)
        {
            if (ModelState.IsValid)
            {
                seguimiento.Id = seguimientos.Count + 1;
                seguimiento.Fecha = DateTime.Now;

                seguimientos.Add(seguimiento);

                TempData["Mensaje"] =
                    "Peso y medidas corporales registrados correctamente.";

                return RedirectToAction("RegistrarEvaluacion");
            }

            return View(seguimiento);
        }


        
        public IActionResult ProgresoFisico(int clienteId)
        {
            var progreso = seguimientos
                .Where(s => s.ClienteId == clienteId)
                .OrderBy(s => s.Fecha)
                .ToList();

            return View(progreso);
        }


       
        public IActionResult HistorialEvaluaciones(int clienteId)
        {
            var historial = seguimientos
                .Where(s => s.ClienteId == clienteId)
                .OrderByDescending(s => s.Fecha)
                .ToList();

            return View(historial);
        }
    }
}