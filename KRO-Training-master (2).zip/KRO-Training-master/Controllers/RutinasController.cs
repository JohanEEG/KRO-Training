using Microsoft.AspNetCore.Mvc;
using KRO_Training_Performance.Models;
using System.Linq;

namespace KRO_Training_Performance.Controllers
{
    public class RutinasController : Controller
    {
        private static List<Rutina> rutinas = new List<Rutina>();

        
        [HttpGet]
        public IActionResult CrearRutina()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CrearRutina(Rutina rutina)
        {
            if (ModelState.IsValid)
            {
                rutina.Id = rutinas.Count + 1;
                rutinas.Add(rutina);

                TempData["Mensaje"] = "Rutina creada correctamente.";

                return RedirectToAction("CrearRutina");
            }

            return View(rutina);
        }

       
        [HttpGet]
        public IActionResult ModificarRutina(int id)
        {
            var rutina = rutinas.FirstOrDefault(r => r.Id == id);

            if (rutina == null)
            {
                return NotFound();
            }

            return View(rutina);
        }

        [HttpPost]
        public IActionResult ModificarRutina(Rutina rutina)
        {
            var rutinaExistente = rutinas.FirstOrDefault(r => r.Id == rutina.Id);

            if (rutinaExistente == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                rutinaExistente.Nombre = rutina.Nombre;
                rutinaExistente.Descripcion = rutina.Descripcion;
                rutinaExistente.Ejercicios = rutina.Ejercicios;
                rutinaExistente.Nivel = rutina.Nivel;
                rutinaExistente.DuracionMinutos = rutina.DuracionMinutos;

                TempData["Mensaje"] = "Rutina modificada correctamente.";

                return RedirectToAction("ModificarRutina", new { id = rutina.Id });
            }

            return View(rutina);
        }

        
        [HttpGet]
        public IActionResult EliminarRutina(int id)
        {
            var rutina = rutinas.FirstOrDefault(r => r.Id == id);

            if (rutina == null)
            {
                return NotFound();
            }

            return View(rutina);
        }

        [HttpPost]
        public IActionResult ConfirmarEliminarRutina(int id)
        {
            var rutina = rutinas.FirstOrDefault(r => r.Id == id);

            if (rutina == null)
            {
                return NotFound();
            }

            rutinas.Remove(rutina);

            TempData["Mensaje"] = "Rutina eliminada correctamente.";

            return RedirectToAction("ListaRutinas");
        }

        
        [HttpGet]
        public IActionResult AsignarRutina()
        {
            ViewBag.Rutinas = rutinas;

            return View();
        }

        [HttpPost]
        public IActionResult AsignarRutina(int rutinaId, int clienteId)
        {
            var rutina = rutinas.FirstOrDefault(r => r.Id == rutinaId);

            if (rutina == null)
            {
                return NotFound();
            }

            TempData["Mensaje"] =
                "Rutina asignada correctamente al cliente.";

            return RedirectToAction("AsignarRutina");
        }

        // MÓDULO 13: Consultar rutinas asignadas
        public IActionResult RutinasAsignadas()
        {
            return View(rutinas);
        }

        // Lista auxiliar para visualizar las rutinas
        public IActionResult ListaRutinas()
        {
            return View(rutinas);
        }
    }
}